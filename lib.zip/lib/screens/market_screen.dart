import 'package:flutter/material.dart';

class MarketScreen extends StatelessWidget {
  static const ROUTE_NAME = '/market';

  @override
  Widget build(BuildContext context) {
    return Center(child: Text('This is market screen!'),);
  }
}
