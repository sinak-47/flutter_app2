import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  static const ROUTE_NAME = '/profile';

  @override
  Widget build(BuildContext context) {
    return Center(child: Text('This is profile screen!'),);
  }
}
