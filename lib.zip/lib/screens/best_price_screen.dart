import 'package:flutter/material.dart';

class BestPriceScreen extends StatelessWidget {
  static const ROUTE_NAME = '/best_price';

  @override
  Widget build(BuildContext context) {
    return Center(child: Text('This is best price screen!'),);
  }
}
